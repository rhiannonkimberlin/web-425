/*
============================================
; Title:  kimberlin-exercise-1.4
; Author: Professor Krasso
; Date:   December 19
; Modified By: Rhiannon Kimberlin
; Description: ts-examples
;===========================================
*/

export interface IPerson {
    firstName: string;
    lastName: string;
}